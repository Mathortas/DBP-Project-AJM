from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import  authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Usuario, Matricula, Curso, Horario, Tarea

def index(request):
    cursos = Curso.objects.all()
    return render(request, "my_ucsp/index.html", {"cursos": cursos})


def calendario(request):
    return render(request, 'my_ucsp/calendario.html')

def curso_detalle(request, curso_id):
    curso = get_object_or_404(Curso, pk=curso_id)
    horarios = Horario.objects.filter(id_curso=curso)
    tareas   = Tarea.objects.filter(id_curso=curso)
    return render(request, 'my_ucsp/curso-detalle.html', {
        'curso': curso,
        'horarios': horarios,
        'tareas': tareas,
    })



def login_view(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')

        # 1. Intentar localizar usuario por email
        try:
            user_obj = User.objects.get(email=email)
        except User.DoesNotExist:
            messages.error(request, "Usuario o contraseña incorrectos.")
            return redirect('login')

        # 2. Autenticar usando el username real
        user = authenticate(request, username=user_obj.username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, "Usuario o contraseña incorrectos.")
            return redirect('login')

    # GET
    return render(request, 'my_ucsp/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def editar_perfil(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST['nombre']
        user.email = request.POST['email']
        user.save()
        # Actualiza o crea el perfil en tu tabla Usuario
        perfil_obj, created = Usuario.objects.update_or_create(
            correo=user.email,
            defaults={'nombre_usuario': user.username}
        )
        messages.success(request, 'Perfil actualizado correctamente.')
        return redirect('perfil')
    return render(request, 'my_ucsp/editar-perfil.html')

@login_required
def perfil(request):
    user = request.user
    # Intentamos cargar la fila de Usuario según el correo
    perfil_obj = Usuario.objects.filter(correo=user.email).first()

    # Buscamos matrículas para este usuario (tabla Matricula tiene id_estudiante → Usuario)
    matriculas = Matricula.objects.filter(id_estudiante__correo=user.email)
    if matriculas.exists():
        # Extraemos los objetos Curso de cada Matricula
        cursos = [m.id_curso for m in matriculas]
    else:
        # Si no hay matrículas, mostramos todos los cursos (o podrías filtrar por docente)
        cursos = Curso.objects.all()

    return render(request, 'my_ucsp/perfil.html', {
        'perfil': perfil_obj,
        'cursos': cursos,
    })
