//Todavia no añadiremos scripts hasta que la parte de la funcionalidad este al 100 :v
