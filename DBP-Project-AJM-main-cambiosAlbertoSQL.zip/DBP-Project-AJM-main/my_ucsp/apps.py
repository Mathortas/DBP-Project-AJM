from django.apps import AppConfig


class MyUcspConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'my_ucsp'
